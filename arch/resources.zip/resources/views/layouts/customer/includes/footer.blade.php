<?php /*https://code.jquery.com/jquery-3.5.1.min.js*/ ?>
<script src="{{asset('assets/js/jquery-2.2.3.min.js')}}"></script>
<script src="{{asset('assets/customer/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/customer/plugins/jquery-ui-1.12.1/jquery-ui.js')}}"></script>