  <!-- Footer -->
 <footer class="page-footer font-small footer_color pt-4 mt-5">
         <!-- Footer Links -->
   <div class="container text-center text-md-left mt-4">
            <!-- Grid row -->
      <div class="row">
               <!-- Grid column -->
          <div class="col-md-4 mt-md-0 mt-3">
                  <!-- Grid column -->
                   <!-- Links -->
                 <h5 class="text-uppercase">About Us</h5>
                     <ul class="list-unstyled">
                          <li>
                              <a href="{{route('table')}}">Table</a>
                          </li>
                          <li>
                              <a href="{{route('profile')}}">Profile</a>
                          </li>
                           <li>
                               <a href="{{route('faq')}}">FAQ</a>
                           </li>
                           <li>
                             <a href="{{route('dashboard')}}">Dashboasd</a>
                           </li>
                     </ul>
                      <!-- Grid column -->
               </div>
               <!-- Grid column -->
                    <hr class="clearfix w-100 d-md-none pb-3">
               <!-- Grid column -->
                   <div class="col-md-4 mb-md-0 mb-3">
                  <!-- Links -->
                     <h5 class="text-uppercase">ANALYTICS</h5>
                    <ul class="list-unstyled">
                     <li>
                        <a href="#!">Education</a>
                     </li>
                     <li>
                        <a href="#!">Webinars</a>
                     </li>
                     <li>
                        <a href="#!">Webinars Forex</a>
                     </li>
                     <li>
                        <a href="#!">Blog</a>
                     </li>
                  </ul>
               </div>
               <!-- Grid column -->
               <!-- Grid column -->
               <div class="col-md-4 mb-md-0 mb-3">
                  <!-- Links -->
                   <h5 class="text-uppercase">ANALYTICS</h5>
                    <ul class="list-unstyled">
                      <li>
                        <a href="#!">Insights</a>
                       </li>
                       <li>
                        <a href="#!">Assets</a>
                      </li>
                      <li>
                        <a href="#!">Affiliate program</a>
                     </li>
                     <li>
                        <a href="#!">Support</a>
                     </li>
                  </ul>
               </div>
               <!-- Grid column -->
            </div>
            <!-- Grid row -->
         </div>
         <!-- Footer Links -->
         <!-- Copyright -->
            <div class="footer-copyright text-center py-3">© 2020 Copyright:
              <a href="#"> Quick Infotech. All Rights Reserved.</a>
           </div>
         <!-- Copyright -->
      </footer>
      <!-- Footer -->
  
