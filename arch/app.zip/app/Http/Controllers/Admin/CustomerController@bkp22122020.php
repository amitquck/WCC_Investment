<?php 
	namespace App\Http\Controllers\Admin;
	use Illuminate\Support\Collection;
	use Illuminate\Http\Request;	
	use App\Http\Controllers\Controller;
	use Illuminate\Support\Facades\Hash;
	use Illuminate\Support\Facades\Auth;
	use App\Model\CustomerDetail;
	use App\Model\CustomerReward;
	use App\Model\AssociateReward;
	use App\Model\CustomerInvestment;
	use App\Model\CustomerTransactions;
	use App\Model\AssociateTransactions;
	use App\Model\CustomerInterestPercentage;
	use App\Model\AssociateCommissionPercentage;
	use App\Helpers as Helper;
	use App\User;
	use Redirect;
	use DB; 
	use App\Zipcode;
	use App\Model\Country;
	use App\Model\State;
	use App\Model\City;
	use Carbon\Carbon;


	class CustomerController extends Controller
	{
		public function index(){
	      	if(\Auth::user()->login_type == 'superadmin' || \Auth::user()->login_type == 'employee'){
				$users = User::whereLoginType('customer')->orderBy('created_at')->paginate(10);
				$countries = Country::get()->pluck('name','id');
	        	return view('admin.customers.index',compact('users','countries'));
	        }
		}

		public function add()
		{
			$countries = Country::get()->pluck('name','id');
        	return view('admin.customers.add',compact('countries'));
		}
		public function store(Request $request){
			// dd($request->all());
			$user_id = \Auth::user()->id;
				$this->validate($request,[
				'name' => 'required',
				'customer_id' => 'required',
				'dob' => 'nullable',
				'sex' => 'nullable',
				'father_husband_wife' => 'nullable',
				'nationality' => 'nullable',
				'email' => 'required|email',
				'mobile' => 'required',
				'customer_invest' => 'required',
				'address_one' => 'nullable',
				'address_two' => 'nullable',
				'country_id' => 'nullable',
				'state_id' => 'nullable',
				'city_id' => 'nullable',
				'zipcode' => 'nullable',
				'account_holder_name' => 'nullable',
				'bank_name' => 'nullable',
				'account_number' => 'nullable',
				'ifsc_code' => 'nullable',
				'nominee_name' => 'nullable',
				'nominee_dob' => 'nullable',
				'nominee_sex' => 'nullable',
				'nominee_relation_with_applicable' => 'nullable',
				'nominee_address_one' => 'nullable',
				'nominee_address_two' => 'nullable',
				'nominee_zipcode' => 'nullable',
				'nominee_country_id' => 'nullable',
				'nominee_state_id' => 'nullable',
				'nominee_city_id' => 'nullable',
				'nominee_age' => 'nullable',
				'password' => 'required|confirmed',
				
			]);
			if($request->sum_of_commission > 36){
				return redirect()->back()->with('error','Sum Of Commission is not Greater Than 36');
			}

			DB::beginTransaction();

			try{
				$customer = new User;
				$customer->login_type = 'customer';
				$customer->name = $request->name;
				$customer->password = Hash::make($request->password);
				$customer->mobile = $request->mobile;
				$customer->code = $request->customer_id;
				$customer->email = $request->email;
				$customer->created_by = $user_id;
				$customer->status = 1;
				$customer->save();	
				// dump($customer->customerdetails());
				// dd($customer);
				$customer->customerdetails()->create([
					'dob' => date('Y-m-d',strtotime($request->dob)),
					'age' => $request->age,
					'nationality' => $request->nationality,
					'sex' => $request->sex,
					'father_husband_wife' => $request->father_husband_wife,
					'address_one' => $request->address_one,
					'address_two' => $request->address_two,
					'city_id' => $request->city_id,
					'state_id' => $request->state_id,
					'country_id' => $request->country_id,
					'zipcode' => $request->zipcode,
					'account_holder_name' => $request->account_holder_name,
					'bank_name' => $request->bank_name,
					'account_number' => $request->account_number,
					'ifsc_code' => $request->ifsc_code,
					'nominee_name' => $request->nominee_name,
					'nominee_age' => $request->nominee_age,
					'nominee_sex' => $request->nominee_sex,
					'nominee_dob' => date('Y-m-d',strtotime($request->nominee_dob)),
					'nominee_relation_with_applicable' => $request->nominee_relation_with_applicable,
					'nominee_address_one' => $request->address_one,
					'nominee_address_two' => $request->address_two,
					'nominee_city_id' => $request->city_id,
					'nominee_state_id' =>$request->state_id,
					'nominee_country_id' => $request->nominee_country_id,
					'nominee_zipcode' => $request->nominee_zipcode,
					'created_by' => $user_id,
					
				]);

				$customer->customerinterestpercents()->create([
					'interest_percent' => $request->customer_invest,
					'start_date' => date('Y-m-d'),
					'active_status' => 1,
					'created_by' => $user_id,
				]);

				if(sizeof(array_filter($request->associate))){
					foreach($request->associate as $key => $value){
						if($value>0){
							$customer->associatecommissions()->create([
								'associate_id' => $value,
								'customer_id' => $customer->id,
								'start_date' => date('Y-m-d'),
								'commission_percent' =>$request->commission[$key],
								'status' => 1,
								'created_by' => $user_id,
							]);
						}
					}
				}

				DB::commit();
			}catch(\Exception $e){
				dd($e->getMessage());
				DB::rollback();

			}
			
			// dd($customer->customerdetail());
		return redirect()->route('admin.customer_commission', [encrypt($customer->id)])->withSuccess('Customer Successfully Added');

		}

		public function edit(Request $request,$id){
			// dd($id);
			$countries = Country::get();
			$states = State::get();
			$cities = City::get();
			$customer = User::where('id',decrypt($id))->firstOrFail();
			// dd($customer->customerdetails);
			return view('admin.customers.edit',compact('customer','countries','states',
				'cities'));

		}

		public function update(Request $request){
			// dd($request->id);
			$this->validate($request,[
				'name' => 'required',
				'customer_id' => 'required',
				'dob' => 'nullable',
				'sex' => 'nullable',
				'father_husband_wife' => 'nullable',
				'nationality' => 'nullable',
				'email' => 'required|email',
				'mobile' => 'required',
				'address_one' => 'nullable',
				'address_two' => 'nullable',
				'country_id' => 'nullable',
				'state_id' => 'nullable',
				'city_id' => 'nullable',
				'zipcode' => 'nullable',
				'account_holder_name' => 'nullable',
				'bank_name' => 'nullable',
				'account_number' => 'nullable',
				'ifsc_code' => 'nullable',
				'nominee_name' => 'nullable',
				'nominee_dob' => 'nullable',
				'nominee_sex' => 'nullable',
				'nominee_relation_with_applicable' => 'nullable',
				'nominee_address_one' => 'nullable',
				'nominee_address_two' => 'nullable',
				'nominee_zipcode' => 'nullable',
				'nominee_country_id' => 'nullable',
				'nominee_state_id' => 'nullable',
				'nominee_city_id' => 'nullable',
				'nominee_age' => 'nullable',
				
			]);
			$uploaded = '';	
			if($request->isMethod('post')){
				
				$customer = User::where('id',$request->id)->firstOrFail();
				if($customer->count() > 0){
					$customer->login_type = 'customer';
					$customer->name = $request->name;
					// $customer->password = Hash::make($request->password);
					$customer->mobile = $request->mobile;
					$customer->code = $request->customer_id;
					$customer->email = $request->email;
					$customer->created_by = \Auth::user()->id;
					$customer->status = 1;
					$customer->save();
					// $uploaded = true;	
					// dump($customer->customerdetails());
					// if($customer->customerdetails()->count() > 0){
						$customer->customerdetails()->update([
						'dob' => date('Y-m-d',strtotime($request->dob)),
						'age' => $request->age,
						'nationality' => $request->nationality,
						'sex' => $request->sex,
						'father_husband_wife' => $request->father_husband_wife,
						'address_one' => $request->address_one,
						'address_two' => $request->address_two,
						'city_id' => $request->city_id,
						'state_id' => $request->state_id,
						'country_id' => $request->country_id,
						'zipcode' => $request->zipcode,
						'account_holder_name' => $request->account_holder_name,
						'bank_name' => $request->bank_name,
						'account_number' => $request->account_number,
						'ifsc_code' => $request->ifsc_code,
						'nominee_name' => $request->nominee_name,
						'nominee_age' => $request->nominee_age,
						'nominee_sex' => $request->nominee_sex,
						'nominee_dob' => date('Y-m-d',strtotime($request->nominee_dob)),
						'nominee_relation_with_applicable' => $request->nominee_relation_with_applicable,
						'nominee_address_one' => $request->address_one,
						'nominee_address_two' => $request->address_two,
						'nominee_city_id' => $request->city_id,
						'nominee_state_id' => $request->state_id,
						'nominee_country_id' => $request->nominee_country_id,
						'nominee_zipcode' => $request->nominee_zipcode,
						
					]);
					// }else{
					// 	$customer->customerdetails()->create([
					// 	'dob' => date('Y-m-d',strtotime($request->dob)),
					// 	'age' => $request->age,
					// 	'nationality' => $request->nationality,
					// 	'sex' => $request->sex,
					// 	'father_husband_wife' => $request->father_husband_wife,
					// 	'address_one' => $request->address_one,
					// 	'address_two' => $request->address_two,
					// 	'city_id' => $request->city_id,
					// 	'state_id' => $request->state_id,
					// 	'country_id' => $request->country_id,
					// 	'zipcode' => $request->zipcode,
					// 	'account_holder_name' => $request->account_holder_name,
					// 	'bank_name' => $request->bank_name,
					// 	'account_number' => $request->account_number,
					// 	'ifsc_code' => $request->ifsc_code,
					// 	'nominee_name' => $request->nominee_name,
					// 	'nominee_age' => $request->nominee_age,
					// 	'nominee_sex' => $request->nominee_sex,
					// 	'nominee_dob' => date('Y-m-d',strtotime($request->nominee_dob)),
					// 	'nominee_relation_with_applicable' => $request->nominee_relation_with_applicable,
					// 	'nominee_address_one' => $request->address_one,
					// 	'nominee_address_two' => $request->address_two,
					// 	'nominee_city_id' => $request->city_id,
					// 	'nominee_state_id' => $request->state_id,
					// 	'nominee_country_id' => $request->nominee_country_id,
					// 	'nominee_zipcode' => $request->nominee_zipcode,
						
					// ]);
					// }					
						
					// $uploaded = true;
					return redirect('admin/customers')->with('success','Customer Updated Successfully!');
				}
				// if($uploaded ==  true){
					
				// }else{
				// 	return redirect('admin/customers')->with('info','Nothing Change');
				// }
				
				return redirect('admin/customers')->with('error','Something Went Wrong');
			}
			
		}
		public function view(Request $request,$id)
		{
			// dd($id);
			$customer = User::whereId(decrypt($id))->first();
			return view('admin.customers.view',compact('customer'));
		}
		public function status($id){
			$customer = User::where('id',decrypt($id))->firstOrFail();
			$customer->status = !$customer->status;
			$customer->save();
			return redirect()->back()->with('success','Status Updated Successfully!');
		}

		public function destroy($id){
			$customer = User::where('id',decrypt($id))->delete();
			CustomerDetail::where('customer_id',decrypt($id))->delete();
        	return redirect()->back()->with('success','Customer Deleted Successfully!');
		}


		public function getZip(Request $request){
			// dd($request->all());
        $zipcodeData = null;
        if($request->has('zip') && strlen($request->zip) == 6){
            $zipcode = Zipcode::whereZipcode($request->zip)->first();

				// dd($zipcode);
                $zipcodeData['country'] = $zipcode->country->id;
                $zipcodeData['country_name'] = $zipcode->country->name;
                $zipcodeData['state'] = $zipcode->state->id;
                $zipcodeData['state_name'] = $zipcode->state->name;
                $zipcodeData['city'] = $zipcode->city->id;
                $zipcodeData['city_name'] = $zipcode->city->name;
            
        }
        echo json_encode($zipcodeData);
        exit;
    }
	public function customerCommission($customerId){
		$customer = User::find(decrypt($customerId));
		$associate = User::whereLoginType('associate')->get();
        if ($customer === null) {
           return redirect('/admin/customers')->withError('Customer Not Found');
        }
        return view('admin/customers/customer_commission',['customer' => $customer,'associate'=>$associate]);
	}

	public function customerAssociateCommission($customerId){
		$customer = User::find(decrypt($customerId));
		// dd($customer->id);
		$customer_interest_percent = CustomerInterestPercentage::where('customer_id',decrypt($customerId))->where('end_date',Null)->where('active_status',1)->first();
		// dd($customer_interest_percent);
		if($customer_interest_percent == null){
			return redirect('/admin/customers')->withError('Customer Not Found');
		}
		$associate = User::whereLoginType('associate')->get();
        if ($associate === null) {
           return redirect('/admin/customers')->withError('Customer Not Found');
        }
        return view('admin/customers/add_customer_associate_percent',['customer' => $customer,'associate'=>$associate,'customer_interest_percent'=>$customer_interest_percent]);
	}

	public function investmentStore(Request $request,$id)
	{
		// dd(auth()->user()->id);
		$user_id = \Auth::user()->id;
		// dd($user_id);
		$this->validate($request,[
			'amount' => 'required|numeric|min:0',
			'deposit_date' => 'required',
			'payment_type' => 'required|min:1',
			'remarks' => 'required|min:1',
			
			]);

		$customer = User::find(decrypt($id));
		// dd($customer);
		$interest_rate = CustomerInterestPercentage::where('customer_id',$customer->id)->where('active_status',1)->first();
		// dd($interest_rate);
		if(!$customer->customerinvestments->count()){
			$interest_rate->start_date = $request->deposit_date;
			$interest_rate->save();
		}

		$commissions = AssociateCommissionPercentage::where('customer_id',$customer->id)->where('status',1)->get();//status = active_status
		// dd($customer->associatecommissions);
		if($customer->associatecommissions->count()){
			foreach ($commissions as $key => $commission) {
				$commission->start_date = $request->deposit_date;
				$commission->save();
			}
		}
		
		$customer->customerinvestments()->create([
			'amount' => $request->amount,
			'deposit_date' => $request->deposit_date,
			'customer_interest_rate' => $interest_rate->interest_percent,
			'created_by' => $user_id,
		]);

		$customer->customertransactions()->create([
			'customer_id' => $customer->id,
			'payment_type' =>$request->payment_type,
			'transaction_type' =>'deposit',
			'amount' => $request->amount,
			'cr_dr' => 'cr',
			'remarks' => $request->remarks,
			'bank_name' => $request->bank_name,
			'cheque_dd_number' => $request->cheque_dd_number,
			'deposit_date' => $request->deposit_date,
			'cheque_dd_date' => isset($request->date)?$request->date:Null,
			'status' => 1,
			'created_by' => $user_id,
		]);
		return redirect('admin/customers')->with('success',$customer->name. ' Successfully Deposit');

	}


	public function commissionStore(Request $request,$id){
		// dd($request->all());
		// dd(array_filter($request->associate));
		$this->validate($request,[
			'customer_invest' => 'required|numeric|min:0',
			
			]);
		if($request->sum_of_commission > 36){
			return redirect()->back()->with('error','Sum Of Commission is not Greater Than 36');
		}
		if($id === null){
			return redirect('admin/customers')->with('error','Invalid Request');
		}
		$customer = User::find(decrypt($id));
		$customer_investment = CustomerInvestment::whereCustomerId(decrypt($id))->first();
		$customer_investment->customer_interest_rate = $request->customer_invest;
		$customer_investment->save();
		// dd($request->associate);
		if(sizeof(array_filter($request->associate))){
			foreach($request->associate as $key => $value){
				if($value>0){
					$customer->associatecommissions()->create([
						'associate_id' => $value,
						'customer_id' => $customer->id,
						'start_date' => $customer_investment->deposit_date,
						// 'interest_amount' => $request->customer_invest,
						'commission_percent' =>$request->commission[$key],
						'status' => 1,
					]);
				}
			}
		}
		return redirect('admin/customers')->with('success',$customer->name. ' Successfully Add Commission');
	}
	public function searchAssociateCommission(Request $request){
		$search = explode(',',$request->get('term'));
			$search = end($search);
				// dd($search);
			$result = 'App\User'::select('id',DB::raw('name as label'))->where('name', 'LIKE', '%'. $search. '%')->whereLoginType('associate')->get();
          return response()->json($result);
	}
	public function customerDepositForm(Request $request){
			$customer = User::where('id',$request->id)->firstOrFail();
			// $profitMasters = Profit::whereStatus(1)->firstOrFail();
			// dd($profitMasters->profit_percent);
			return view('admin.customers.addtransaction',compact('customer'));
		}

	// public function customerDeposit(Request $request){
	// 	// dd($request->all());
	// 	$this->validate($request,[
	// 		'customer_id' => 'required|exists:users,id',
	// 		'amount' => 'required|numeric|min:0',
	// 		'deposit_date' => 'required',
	// 		'payment_type' => 'required|min:1',

	// 		'remarks' => 'required|min:1',
	// 	]);

	// 	$customer = User::where('id',$request->customer_id)->firstOrFail();
	// 	// dd($customer);
		
	// 	$customer->customertransactions()->create([
	// 		'payment_type' =>$request->payment_type,
	// 		'transaction_type' =>'deposit',
	// 		'amount' => $request->amount,
	// 		'cr_dr' => 'cr',
	// 		'remarks' => $request->remarks,
	// 		'bank_name' => $request->bank_name,
	// 		'cheque_dd_number' => $request->cheque_dd_number,
	// 		'deposit_date' => $request->deposit_date,
	// 		'cheque_dd_date' => isset($request->date)?$request->date:Null,
	// 		'status' => 1,
	// 	]);
	// 	return redirect()->back()->with('success','Successfully Added Investment Amount');
	// }

	public function customerWithdrawForm(Request $request)
	{
		$customer = User::where('id',$request->id)->firstOrFail();
		return view('admin.customers.addwithdraw',compact('customer'));
	}

	public function customerWithdraw(Request $request){
		// dd($request->all());
		$this->validate($request,[
			'customer_id' => 'required|exists:users,id',
			'amount' => 'required|numeric|min:0',
			'deposit_date' => 'required',
			'payment_type' => 'required|min:1',
			'remarks' => 'required|min:1',
		]);

		// $customer = User::where('id',$request->customer_id)->firstOrFail();
		$customer = User::whereId($request->customer_id)->first();
		// dd($customer);
		
		$customer->customertransactions()->create([
			'customer_id' => $request->customer_id,
			'payment_type' =>$request->payment_type,
			'transaction_type' =>'withdraw',
			'amount' => $request->amount,
			'cr_dr' => 'dr',
			'remarks' => $request->remarks,
			'bank_name' => $request->bank_name,
			'cheque_dd_number' => $request->cheque_dd_number,
			'deposit_date' => $request->deposit_date,
			'cheque_dd_date' => isset($request->date)?$request->date:Null,
			'status' => 1,
		]);
		return redirect()->back()->with('success','Successfully Added Withdraw Amount');
	}


	public function generatePayout(){
		return view('admin.customers.generate-payout');
	}

	public function payoutGenerates(Request $request)
	{
		// dd(CustomerReward::where('id',2)->first()->customertransactions);
		$this->validate($request,[
			'month'=>'required|numeric|min:1|not_in:0',
		]);
		
		$month = $request->month;
		$year = $request->year;
		
		$customers = User::whereHas('customertransactions',function($q) use ($year,$month){
			return $q->where('deposit_date', '<=', Carbon::parse($year.'-'.$month)->format('Y-m-t'));
		})->whereLoginType('customer')->get();
		
		// dd(date('Y-m-t',strtotime($year.'-'.$month)));
		if(date('Y-m-t',strtotime($year.'-'.$month)) > date('Y-m-d')){
			return redirect()->back()->with('error','Sorry! Can not generate-payout.');
		}
		foreach($customers as $customer){
			CustomerReward::where('month', Carbon::parse($year.'-'.$month)->format('m'))->where('year', Carbon::parse($year.'-'.$month)->format('Y'))->where('customer_id',$customer->id)->where('reward_type', 'interest')->get()->each(function($reward){
				$reward->delete();
			});	//Each for cascade delete
			AssociateReward::where('month', Carbon::parse($year.'-'.$month)->format('m'))->where('year', Carbon::parse($year.'-'.$month)->format('Y'))->where('customer_id',$customer->id)->where('reward_type', 'commission')->get()->each(function($reward){
				$reward->delete();
			});	//Each for cascade delete

			// CustomerTransactions::where('deposit_date', Carbon::parse($year.'-'.$month)->format('Y-m'))->where('customer_id',$customer->id)->where('transaction_type', 'interest')->delete();

			$start_date = Carbon::parse($year.'-'.$month.'-01')->format('Y-m-d');
			
			$customer_transactions = CustomerTransactions::where('deposit_date','>=',Carbon::parse($year.'-'.$month.'-01')->format('Y-m-d'))->where('deposit_date','<=',Carbon::parse($year.'-'.$month.'-01')->format('Y-m-t'))->where('customer_id',$customer->id)->get();
			if($customer_transactions->count()){
				foreach($customer_transactions as $customer_transaction){
				
					// $end_date = Carbon::parse($year.'-'.$month.'-30')->format('Y-m-t');
					// $customerfirsttransaction = $customer->customertransactions->orderBy('deposit_date')->first();
					// if($customerfirsttransaction->id == $customer_transaction->id){
					// 	$start_date = $customer_transaction->deposit_date;
					// }

					// if($customer_transaction->cr_dr == 'cr'){

					// }else{
					// 	$end_date = $customer_transaction->deposit_date;
					// }

					$end_date = Carbon::parse($customer_transaction->deposit_date)->subDays(1)->format('Y-m-d');



					$this->calculation($customer,$start_date,$end_date);
					$start_date = $customer_transaction->deposit_date;

					// if(Carbon::parse($investment->deposit_date)->format('Y-m') == Carbon::parse($year.'-'.$month)->format('Y-m')){
					// 	$start_date = $investment->deposit_date;
					// 	// dd($start_date);
					// }
					// // dd($investment->customertransactions->where('cr_dr','dr'));
					// $customer_withdrawl = $investment->where('cr_dr','dr')->where('deposit_date','<=',$end_date)->where('deposit_date','>=',$start_date);
					// // dd($customer_withdrawl);
					// if($customer_withdrawl->count()){
					// 	// dd('zdgsdg');
					// 	foreach ($customer_withdrawl as $key => $withdrawl) {
					// 		if(($start_date < $withdrawl->deposit_date)){
					// 			$this->calculation($investment,$start_date,Carbon::parse($withdrawl->deposit_date)->subDays(1)->format('Y-m-d'));
					// 		}
					// 		$start_date = $withdrawl->deposit_date;
					// 	}
					// 	$this->calculation($investment,$start_date,$end_date);

					// }else{
					// 	// dd($start_date);
					// 	$this->calculation($investment,$start_date,$end_date);
					// }
				}
				$this->calculation($customer,$start_date,Carbon::parse($year.'-'.$month.'-01')->format('Y-m-t'));
			}else{
				$end_date = Carbon::parse($year.'-'.$month.'-01')->format('Y-m-t');
				$this->calculation($customer,$start_date,$end_date);
			}
			

			
		}
		return redirect()->back()->with('success','Successfully Generated Payouts Of '.Carbon::parse($year.'-'.$month)->format('Y-M'))->withInput();
	}

	protected function calculation($customer,$start_date,$end_date){
		// $interest_rate = $investment->customer_interest_rate;
		// dump($start_date);
		// dump($end_date);
		dd($end_date);
		$balance = $customer->balance($end_date);
		if($balance > 0){

			// dd($balance);
			$original_start_date = $interest_start_date = $start_date;
			$original_end_date = $interest_end_date = $end_date;
			$customer_interest_percents = CustomerInterestPercentage::where('customer_id',$customer->id)->where(function($q) use ($interest_start_date,$interest_end_date){
					return $q->where(function($qu) use ($interest_start_date,$interest_end_date){
							return $qu->where('start_date','>=', $interest_start_date)
									->where('start_date','<=', $interest_end_date);
						})->orWhere(function($qu) use ($interest_start_date,$interest_end_date){
							return $qu->where('end_date','>=', $interest_start_date)
									->where('end_date','<=', $interest_end_date);
						});
			})->get();
			// dd($customer_interest_percents);
			if(!$customer_interest_percents->count()){
				// $customer_interest_percents = CustomerInterestPercentage::where('active_status',1)->where('customer_id',$customer->id)->get();

				$customer_interest_percents = CustomerInterestPercentage::where('customer_id',$customer->id)->where(function($q) use ($start_date,$end_date){
					return $q->where(function($qu) use ($start_date,$end_date){
							return $qu->where('start_date','<', $start_date)
									->where('end_date','>', $start_date);
						});
				})->get();
				// dd($customer_interest_percents);
				if(!$customer_interest_percents->count()){
				 	$customer_interest_percents = CustomerInterestPercentage::where('active_status',1)->where('customer_id',$customer->id)->get();
				}
			}
// dd('sdsd');
			foreach($customer_interest_percents as $key => $customer_interest_percent){
				$swap_dates = false;
			
				if($original_start_date > $customer_interest_percent->start_date){
					$interest_start_date = $original_start_date;
				}

				if($customer_interest_percent->end_date == null){
					$interest_end_date = $original_end_date;
				}else if($customer_interest_percent->end_date != null && $customer_interest_percent->end_date < $original_end_date){
					$interest_end_date = $customer_interest_percent->end_date;
					$swap_dates = true;
				} 

				$interest_rate = $customer_interest_percent->interest_percent;
			

				dd($interest_end_date);
				$payable_days = (Carbon::parse($interest_start_date)->diffInDays($interest_end_date))+1;

				dd($payable_days);
				if($payable_days > 30){
					$payable_days = 30;
				}
				$oneday_interest_amount = (($balance*$interest_rate/100)/12)/30;
				$amount = $oneday_interest_amount*$payable_days;

				
				// dd($customerrewards);
				
			    $customerrewards = new CustomerReward;
				$customerrewards->customer_id = $customer->id;
				$customerrewards->month = Carbon::parse($interest_start_date)->format('m');
				$customerrewards->year = Carbon::parse($interest_start_date)->format('Y');
				$customerrewards->reward_type = 'interest';
				$customerrewards->amount = $amount;
				$customerrewards->start_date = $interest_start_date;
				$customerrewards->end_date = $interest_end_date;
				$customerrewards->total_amount = $balance;
				$customerrewards->interest_percent = $interest_rate;
				$customerrewards->save();

				
				// dd($customerTransaction);
				$customerTransaction = new CustomerTransactions;
				$customerTransaction->customer_id = $customer->id;
				$customerTransaction->transaction_type = 'interest';
				$customerTransaction->respective_table_id = $customerrewards->id;
				$customerTransaction->respective_table_name = 'customer_rewards';
				$customerTransaction->remarks = 'customer_interest';
				$customerTransaction->deposit_date = $interest_end_date;
				$customerTransaction->amount = $amount;
				$customerTransaction->cr_dr = 'cr';
				$customerTransaction->payment_type = 'null';
				$customerTransaction->status = '1';
				$customerTransaction->save();

				if($swap_dates){
					$interest_start_date = Carbon::parse($interest_end_date)->addDays(1)->format('Y-m-d');
					$interest_end_date = $original_end_date;
				}


			}





			$associate_commission_percents = AssociateCommissionPercentage::where('customer_id',$customer->id)->where(function($q) use ($start_date,$end_date){
					return $q->where(function($qu) use ($start_date,$end_date){
							return $qu->where('start_date','>=', $start_date)
									->where('start_date','<=', $end_date);
						})->orWhere(function($qu) use ($start_date,$end_date){
							return $qu->where('end_date','>=', $start_date)
									->where('end_date','<=', $end_date);
						});
			})->get();
			
			if(!$associate_commission_percents->count()){
				// $associate_commission_percents = AssociateCommissionPercentage::where('status',1)->where('customer_id',$customer->id)->get();//status = active_status

				$associate_commission_percents = AssociateCommissionPercentage::where('customer_id',$customer->id)->where(function($q) use ($start_date,$end_date){
					return $q->where(function($qu) use ($start_date,$end_date){
							return $qu->where('start_date','<', $start_date)
									->where('end_date','>', $start_date);
						});
				})->get();

				
				if(!$associate_commission_percents->count()){
				 	$associate_commission_percents = AssociateCommissionPercentage::where('status',1)->where('customer_id',$customer->id)->get();//status = active_status
				}
			}

			foreach($associate_commission_percents as $key => $associate_commission_percent){
				$swap_dates = false;
				if($original_start_date > $associate_commission_percent->start_date){
					$start_date = $original_start_date;
				}
				if($associate_commission_percent->end_date == null){
					$end_date = $original_end_date;
				}else if($associate_commission_percent->end_date != null && $associate_commission_percent->end_date < $original_end_date){
					$end_date = $associate_commission_percent->end_date;
					$swap_dates = true;
				} 
// dd($associate_commission_percent->associate_id);
				$commission_rate = $associate_commission_percent->commission_percent;
			// dd($commission_rate);
// dd($commission_rate);

				$payable_days = (Carbon::parse($start_date)->diffInDays($end_date))+1;
				if($payable_days > 30){
					$payable_days = 30;
				}
				$oneday_commission_amount = (($balance*$commission_rate/100)/12)/30;
				$amount = $oneday_commission_amount*$payable_days;

				
				// dd($customerrewards);
				
			    $associaterewards = new AssociateReward;
			    // dd($associate_commission_percent->associate_id);
				$associaterewards->customer_id = $customer->id;
				$associaterewards->associate_id = $associate_commission_percent->associate_id;
				$associaterewards->month = Carbon::parse($start_date)->format('m');
				$associaterewards->year = Carbon::parse($start_date)->format('Y');
				$associaterewards->reward_type = 'commission';
				$associaterewards->amount = $amount;
				$associaterewards->start_date = $start_date;
				$associaterewards->end_date = $end_date;
				$associaterewards->total_amount = $balance;
				$associaterewards->commission_percent = $commission_rate;
				$associaterewards->save();

				
				// dd($customerTransaction);
				$associateTransaction = new AssociateTransactions;
				$associateTransaction->associate_id = $associate_commission_percent->associate_id;
				$associateTransaction->customer_id = $customer->id;
				$associateTransaction->transaction_type = 'commission';
				$associateTransaction->respective_table_id = $associaterewards->id;
				$associateTransaction->respective_table_name = 'associate_rewards';
				$associateTransaction->remarks = 'associate_commission';
				$associateTransaction->deposit_date = $end_date;
				$associateTransaction->amount = $amount;
				$associateTransaction->cr_dr = 'cr';
				$associateTransaction->payment_type = 'null';
				$associateTransaction->status = '1';
				$associateTransaction->save();

				if($swap_dates){
					$start_date = Carbon::parse($end_date)->addDays(1)->format('Y-m-d');
					$end_date = $original_end_date;
				}


			}



			// foreach($investment->associatecommissions as $associate_reward){

			// 	// $amount = ($balance*$associate_reward->commission_percent)/100;
			// 	$amount = (($balance*$associate_reward->commission_percent/100)/12)/30;

			// 	$associaterewards = AssociateReward::where('month', Carbon::parse($start_date)->format('m'))->where('year', Carbon::parse($start_date)->format('Y'))->where('associate_id',$associate_reward->associate_id)->where('customer_id',$associate_reward->customer_id)->where('customer_investment_id', $associate_reward->customer_investment_id)->where('reward_type', 'commission')->first();

			// 	if(!$associaterewards){
			// 		$associaterewards = new AssociateReward;
			// 		$associaterewards->associate_id = $associate_reward->associate_id;
			// 		$associaterewards->customer_id = $associate_reward->customer_id;
			// 		$associaterewards->customer_investment_id = $associate_reward->customer_investment_id;
			// 		$associaterewards->month = Carbon::parse($start_date)->format('m');
			// 		$associaterewards->year = Carbon::parse($start_date)->format('Y');
			// 		$associaterewards->reward_type = 'commission';
			// 	}

			// 	$associaterewards->amount = $amount;
			// 	$associaterewards->start_date = $start_date;
			// 	$associaterewards->end_date = $end_date;
			// 	$associaterewards->total_amount = $balance;
			// 	$associaterewards->commission_percent = $associate_reward->commission_percent;
			// 	$associaterewards->save();

			// 	$customerTransaction = AssociateTransactions::where('deposit_date', Carbon::parse($end_date)->format('Y-m'))->where('associate_id',$associate_reward->associate_id)->where('customer_id',$associate_reward->customer_id)->where('customer_investment_id', $associate_reward->customer_investment_id)->where('transaction_type', 'interest')->first();

			// 	if(!$associaterewards){
			// 		$customerTransaction = new AssociateTransactions;
			// 		$customerTransaction->associate_id = $associate_reward->associate_id;
			// 		$customerTransaction->customer_id = $associate_reward->customer_id;
			// 		$customerTransaction->customer_investment_id = $associate_reward->customer_investment_id;
			// 		$customerTransaction->respective_table_id = $associaterewards->id;
			// 		$customerTransaction->respective_table_name = 'associate_rewards';
			// 		$customerTransaction->remarks = 'associate_commission';
			// 		$customerTransaction->transaction_type = 'commission';
			// 	}
				
			// 	$customerTransaction->amount = $amount;
			// 	$customerTransaction->cr_dr = 'cr';
			// 	$customerTransaction->payment_type = 'null';
			// 	$customerTransaction->deposit_date = $end_date;
			// 	$customerTransaction->status = '1';
			// 	$customerTransaction->save();
			// }

		}
	}

	// protected function calculation($investment,$start_date,$end_date){
	// 	$interest_rate = $investment->customer_interest_rate;
	// 	$balance = $investment->balance($end_date);
	// 	if($balance > 0){
	// 		$payable_days = (Carbon::parse($start_date)->diffInDays($end_date))+1;
	// 		if($payable_days > 30){
	// 			$payable_days = 30;
	// 		}
	// 		$oneday_interest_amount = (($balance*$interest_rate/100)/12)/30;
	// 		$amount = $oneday_interest_amount*$payable_days;

	// 		$customerrewards = CustomerReward::where('month', Carbon::parse($start_date)->format('m'))->where('year', Carbon::parse($start_date)->format('Y'))->where('customer_id',$investment->customer_id)->where('customer_investment_id', $investment->id)->where('reward_type', 'interest')->first();
	// 		// dd($customerrewards);
	// 		if (!$customerrewards) {
	// 		    $customerrewards = new CustomerReward;
	// 			$customerrewards->customer_id = $investment->customer_id;
	// 			$customerrewards->customer_investment_id = $investment->id;
	// 			$customerrewards->month = Carbon::parse($start_date)->format('m');
	// 			$customerrewards->year = Carbon::parse($start_date)->format('Y');
	// 			$customerrewards->reward_type = 'interest';
	// 		}
			
	// 		$customerrewards->amount = $amount;
	// 		$customerrewards->start_date = $start_date;
	// 		$customerrewards->end_date = $end_date;
	// 		$customerrewards->total_amount = $balance;
	// 		$customerrewards->interest_percent = $investment->customer_interest_rate;
	// 		$customerrewards->save();

	// 		$customerTransaction = CustomerTransactions::where('deposit_date', Carbon::parse($end_date)->format('Y-m'))->where('customer_id',$investment->customer_id)->where('customer_investment_id', $investment->id)->where('transaction_type', 'interest')->first();
	// 		// dd($customerTransaction);
	// 		if(!$customerrewards){
	// 			$customerTransaction = new CustomerTransactions;
	// 			$customerTransaction->customer_id = $investment->customer_id;
	// 			$customerTransaction->customer_investment_id = $investment->id;
	// 			$customerTransaction->transaction_type = 'interest';
	// 			$customerTransaction->respective_table_id = $customerrewards->id;
	// 			$customerTransaction->respective_table_name = 'customer_rewards';
	// 			$customerTransaction->remarks = 'customer_interest';
	// 		}
	// 		$customerTransaction->deposit_date = $end_date;
	// 		$customerTransaction->amount = $amount;
	// 		$customerTransaction->cr_dr = 'cr';
	// 		$customerTransaction->payment_type = 'null';
	// 		$customerTransaction->status = '1';
	// 		$customerTransaction->save();

	// 		foreach($investment->associatecommissions as $associate_reward){

	// 			// $amount = ($balance*$associate_reward->commission_percent)/100;
	// 			$amount = (($balance*$associate_reward->commission_percent/100)/12)/30;

	// 			$associaterewards = AssociateReward::where('month', Carbon::parse($start_date)->format('m'))->where('year', Carbon::parse($start_date)->format('Y'))->where('associate_id',$associate_reward->associate_id)->where('customer_id',$associate_reward->customer_id)->where('customer_investment_id', $associate_reward->customer_investment_id)->where('reward_type', 'commission')->first();

	// 			if(!$associaterewards){
	// 				$associaterewards = new AssociateReward;
	// 				$associaterewards->associate_id = $associate_reward->associate_id;
	// 				$associaterewards->customer_id = $associate_reward->customer_id;
	// 				$associaterewards->customer_investment_id = $associate_reward->customer_investment_id;
	// 				$associaterewards->month = Carbon::parse($start_date)->format('m');
	// 				$associaterewards->year = Carbon::parse($start_date)->format('Y');
	// 				$associaterewards->reward_type = 'commission';
	// 			}

	// 			$associaterewards->amount = $amount;
	// 			$associaterewards->start_date = $start_date;
	// 			$associaterewards->end_date = $end_date;
	// 			$associaterewards->total_amount = $balance;
	// 			$associaterewards->commission_percent = $associate_reward->commission_percent;
	// 			$associaterewards->save();

	// 			$customerTransaction = AssociateTransactions::where('deposit_date', Carbon::parse($end_date)->format('Y-m'))->where('associate_id',$associate_reward->associate_id)->where('customer_id',$associate_reward->customer_id)->where('customer_investment_id', $associate_reward->customer_investment_id)->where('transaction_type', 'interest')->first();

	// 			if(!$associaterewards){
	// 				$customerTransaction = new AssociateTransactions;
	// 				$customerTransaction->associate_id = $associate_reward->associate_id;
	// 				$customerTransaction->customer_id = $associate_reward->customer_id;
	// 				$customerTransaction->customer_investment_id = $associate_reward->customer_investment_id;
	// 				$customerTransaction->respective_table_id = $associaterewards->id;
	// 				$customerTransaction->respective_table_name = 'associate_rewards';
	// 				$customerTransaction->remarks = 'associate_commission';
	// 				$customerTransaction->transaction_type = 'commission';
	// 			}
				
	// 			$customerTransaction->amount = $amount;
	// 			$customerTransaction->cr_dr = 'cr';
	// 			$customerTransaction->payment_type = 'null';
	// 			$customerTransaction->deposit_date = $end_date;
	// 			$customerTransaction->status = '1';
	// 			$customerTransaction->save();
	// 		}
	// 	}
	// }

		

	public function profile(){
        return view('admin.customers.profile');
    }
    
    public function changePassword(){
        return view('admin.customers.changePassword');
    }

    public function changePasswordS(Request $request){
        $this->validate($request,['new_password' => 'required|same:cpassword' ]);
         $user = User::whereId(\Auth::user()->id)->first();
            // dd($user);
            $user->password = Hash::make($request->new_password);
            $user->save();
            return redirect('customer/Profile')->with('success','Password Change Successfully!');

    }
	public function transactionHistory(){
		$u = User::whereLoginType('customer')->whereId(Auth::user()->id)->first();
		$users = [];
		foreach($u->customertransactions as $us){
			array_push($users,$us);
		}
		
		return view('admin/customers/customer-transaction-history',compact('users'));
	}
	public function viewMyInvestment(){
		$users = 'App\Model\CustomerInvestment'::whereCustomerId(Auth::user()->id)->paginate();

		return view('admin/customers/customer-my-investment',compact('users'));
	}
	public function viewInvestmentTransaction($id){

	$customer_investment_id = decrypt($id);
	$users = 'App\Model\CustomerTransactions'::whereCustomerInvestmentId($customer_investment_id)->paginate(10);
	$credit =0;
	$debit =0;
	foreach($users as $key => $user){
		$credit = $user::where('cr_dr','cr')->whereCustomerInvestmentId($customer_investment_id)->sum('amount');
		$debit = $user::where('cr_dr','dr')->whereCustomerInvestmentId($customer_investment_id)->sum('amount');
	}
	
	
	// dd($credit);
	return view('admin/customers/customer-investment-transactions',compact('users','credit','debit'));

	}

	public function customer_investments(Request $request)
	{
		// $invester_id = $request->id;

		// dd(decrypt($request->id));
		$customer_deposits = CustomerTransactions::where('cr_dr','cr')->where('transaction_type','deposit');

		// $id = isset($request->id)?decrypt($request->id):$request->id;
		// dd($id);
		if($request->has('id') && $request->id != '' ){
			$customer_deposits->where('customer_id',$request->id);
			// dd($customer_deposits);
		}
		$customer_deposits = $customer_deposits->paginate(20);
		// dd($customer_deposits);
		return view('admin.customers.admin_customer_investment_report',compact('customer_deposits'));
	}

	public function autocompleteInterest(Request $request)
	{
		if($request->has('term')){
            $results =  User::select('id','code','mobile',DB::raw('name as text'),DB::raw('CONCAT(name,",", mobile) AS label'))->where('name','like','%'.$request->input('term').'%')->get();
            return response()->json($results);
        }
	}

	// ->map(function($customer){
 //            	$customer->id=encrypt($customer->id);
 //            	return $customer;
 //            })

	// public function searchCustomerInvest(Request $request)
	// {
	// 	// dd($request->id);
	// 	$customer_deposits = CustomerTransactions::where('customer_id',$request->id)->where('cr_dr','cr')->where('transaction_type','deposit')->get();
	// 	// dd($customer_deposits);
	// 	return view('admin.customers.admin_customer_investment_report',compact('customer_deposits'));
	// }

	public function customer_interest_invest($customerId)
	{

		$customer = User::find(decrypt($customerId));

		if ($customer === null) {
           return redirect('/admin/customers')->withError('Customer Not Found');
        }

		return view('admin.customers.admin_customer_alltransactions',compact('customer'));
	}


	public function editInterestForm(Request $request)
	{
		// dd($request->id);
		$customer = User::where('id',$request->id)->where('login_type','customer')->firstOrFail();
		return view('admin.customers.edit_interest',compact('customer'));
	}


	public function editInterest(Request $request)
	{
		// dd($request->all());
		$this->validate($request,[
			'customer_interest' => 'required',
			'applicable_date' => 'required',
		]);
		$user_id = \Auth()->user()->id;
		$cust_interst = CustomerInterestPercentage::where('customer_id',$request->customer_id)->where('active_status',1)->first();
		if($cust_interst === null){
			return redirect()->back()->with('error','Customer Not Found');
		}else if($cust_interst->start_date > $request->applicable_date){
			return redirect()->back()->with('error','Applicable date is not valid');
		}
		$cust_interst->active_status = 0;
		$cust_interst->end_date = Carbon::parse($request->applicable_date)->subDays(1)->format('Y-m-d');
		$cust_interst->updated_at = date('Y-m-d');
		$cust_interst->save();

		$interst = new CustomerInterestPercentage;
		$interst->customer_id = $request->customer_id;
		$interst->start_date = $request->applicable_date;
		$interst->interest_percent = $request->customer_interest;
		$interst->active_status = 1;
		$interst->created_by = $user_id;
		$interst->updated_by = $user_id;
		$interst->save();
		return redirect()->back()->with('success','New Interest Rate Applicable on Customer Successfully!');
	}

	public function customerinterestdestroy($id){
		// dd(decrypt($id));
		$customerInterest = CustomerInterestPercentage::where('customer_id',decrypt($id))->where('end_date',null)->where('active_status',1)->delete();
    	return redirect()->back()->with('success','Customer Interest Deleted Successfully!');
	}


	public function editAssociateWithdrawlForm(Request $request)
	{
		$ids = explode(',',$request->id);
		// dd($ids);
		$customer = User::where('id',$ids[0])->where('login_type','customer')->firstOrFail();
		$associate = User::where('id',$ids[1])->where('login_type','associate')->firstOrFail();
		return view('admin.customers.edit_associate_withdrawl',compact('associate','customer'));
	}


	public function editCommission(Request $request)
	{
		// dd($request->all());

		$this->validate($request,[
			'associate_withdrawl' => 'required',
			'start_date' => 'required',
		]);

		$customer_interest_percent = CustomerInterestPercentage::select('interest_percent')->where('customer_id',$request->customer_id)->where('active_status',1)->firstOrFail();

		$totalassociatecommission = AssociateCommissionPercentage::where('associate_id','!=',$request->associate_id)->where('customer_id',$request->customer_id)->where('status',1)->sum('commission_percent');
		if(($totalassociatecommission+$request->associate_withdrawl+$customer_interest_percent->interest_percent)>36){
			return redirect()->back()->with('error','Sum of Interest and Commission can not be greater than 36!');
		}

		$user_id = \Auth()->user()->id;

		$ass_commission = AssociateCommissionPercentage::where('associate_id',$request->associate_id)->where('customer_id',$request->customer_id)->where('status',1)->first();//status = active_status
		// dd($ass_commission);
		if($ass_commission === null){
			return redirect()->back()->with('error','Associate Not Found');
		}
		$ass_commission->status = 0;
		$ass_commission->end_date = Carbon::parse($request->start_date)->subDays(1)->format('Y-m-d');
		$ass_commission->updated_at = date('Y-m-d');
		$ass_commission->save();

		$commission = new AssociateCommissionPercentage;
		$commission->customer_id = $ass_commission->customer_id;
		$commission->associate_id = $request->associate_id;
		$commission->start_date = $request->start_date;
		$commission->commission_percent = $request->associate_withdrawl;
		$commission->status = 1;
		$commission->created_by = $user_id;
		$commission->updated_by = $user_id;
		$commission->save();
		return redirect()->back()->with('success','New Commission Rate Applicable on Associate Successfully!');
	}

	public function associateCommissionDestroy($id){
		// dd(decrypt($id));
		$customerInterest = AssociateCommissionPercentage::where('associate_id',decrypt($id))->where('status',1)->delete();//status = active_status
		// dd($customerInterest);
    	return redirect()->back()->with('success','Associate Commission Deleted Successfully!');
	}
	 public function getCustomers(Request $request){
        if($request->has('term')){
            $results =  User::select('id','code','mobile',DB::raw('name as text'),DB::raw('CONCAT(name,",", mobile) AS label'))->where('name','like','%'.$request->input('term').'%')->where('login_type','customer')->get();
            return response()->json($results);
        }
    }
}
