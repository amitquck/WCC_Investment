
<div class="form-group">
  <label for="name">Name</label>
  <input type="text" class="form-control" name="name" id="Name" placeholder="Enter Country Name" value="{{$country->name}}">
</div>
