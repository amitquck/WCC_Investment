@extends('layouts.admin.default')
@section('content')
  <!-- Breadcrumb -->
  <nav aria-label="breadcrumb" class="main-breadcrumb">
    <ol class="breadcrumb breadcrumb-style2">
      <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
      <li class="breadcrumb-item"><a href="javascript:void(0)">Customers</a></li>
      <li class="breadcrumb-item active" aria-current="page">Customers On Hold</li>
    </ol>
  </nav>
  <!-- /Breadcrumb -->
  @include('flash')
  @if(empcan('export_on_hold') || Auth::user()->login_type == 'superadmin')
    <div class="col-md-12">
      <a href="{{route('admin.hold_customer_excel_export')}}" class="btn btn-danger pull-right"> Excel Export</a>
    </div><br><br>
  @endif
  <div class="card card-style-1 mt-3">
    <div class="table-responsive">
      <table class="table table-nostretch table-align-middle mb-0">
        <thead>
          <tr>
            <th scope="col" class="text-center">Sr No:</th>
            <th scope="col">Customer Code</th>
            <th scope="col">Customer Name</th>
            <th scope="col">Contact Details</th>
            <th scope="col"class="text-center">Created At</th>
            <th>Balance</th>
            <th>Hold Remarks</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          @if($customers->count()>0)
          @foreach($customers as $key => $customer)
            <tr>
              <td class="text-center">{{($customers->currentpage()-1)*$customers->perpage()+$key+1}}.</td>
              
              <td class="text-info"><a @if(empcan('view_detail_on_hold') || Auth::user()->login_type == 'superadmin') href="{{route('admin.customer_detail',encrypt($customer->id))}}" @endif data-toggle="tooltip" title="View Details">{{$customer->code}}</a></td>
              <td>{{$customer->name}}</td>
              <td>
                <i class="material-icons text-success">phone</i>{{$customer->mobile}}<br>
                <i class="material-icons text-warning">mail</i> {{$customer->email?$customer->email:'N/A'}}<br>
              </td>
              <td class="text-center">
                  {{Carbon\Carbon::parse($customer->created_at)->format('j-m-Y')}}
              </td>
              <td class="text-danger">
                @if($customer->customer_current_balance() > 0)
                  <p class="text-success">₹ {{$customer->customer_current_balance()}}</p>
                @else
                  <p class="text-danger">₹ {{$customer->customer_current_balance()}}</p>
                @endif
              </td>
              <td class="text-danger">{{$customer->hold_remarks}}</td>
              <td>
                @if(empcan('view_transaction_on_hold') || Auth::user()->login_type == 'superadmin')
                  <a href="{{route('admin.customerAllTransactions',encrypt($customer->id))}}" class="btn btn-default btn-link btn-icon bigger-130 text-primary viewAssociate" data-toggle="tooltip" title="View Transactions"  data-id="{{$customer->id}}"><i class="material-icons">visibility</i></a>
                @endif
              </td>
              
            </tr>
          @endforeach
           @else
          <tr><td colspan="10"><h3 class="text-center text-danger">No Record Found</h3></td></tr>
          @endif

        </tbody>
      </table>
    </div>
  </div>
       
       


{{$customers->links()}}
@endsection


@section('page_js')

@endsection